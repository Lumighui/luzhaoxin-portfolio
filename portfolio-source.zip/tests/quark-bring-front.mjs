const port = Number(process.env.CDP_PORT || 9229);
const targetUrlPart = process.env.TARGET_URL_PART || "github.com";
const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
const target = targets.find((item) =>
  item.type === "page" && item.url.includes(targetUrlPart)
);
if (!target) throw new Error(`Page target not found: ${targetUrlPart}`);

const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});

let nextId = 0;
const pending = new Map();
socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  if (!message.id) return;
  const handler = pending.get(message.id);
  if (!handler) return;
  pending.delete(message.id);
  if (message.error) handler.reject(new Error(message.error.message));
  else handler.resolve(message.result);
});

function send(method, params = {}) {
  const id = ++nextId;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
  });
}

await send("Page.bringToFront");
try {
  const windowInfo = await send("Browser.getWindowForTarget", { targetId: target.id });
  await send("Browser.setWindowBounds", {
    windowId: windowInfo.windowId,
    bounds: { windowState: "normal", left: 80, top: 80, width: 1440, height: 1000 }
  });
  console.log(JSON.stringify({ broughtToFront: true, windowId: windowInfo.windowId }));
} catch (error) {
  console.log(JSON.stringify({ broughtToFront: true, resizeError: error.message }));
}
socket.close();
