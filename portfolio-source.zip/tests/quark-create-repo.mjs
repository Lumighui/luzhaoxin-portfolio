const port = Number(process.env.CDP_PORT || 9229);
const repoName = process.env.REPO_NAME || "luzhaoxin-portfolio";
const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
const target = targets.find((item) =>
  item.type === "page" && item.url === "https://github.com/new"
);
if (!target) throw new Error("New repository page target not found");

const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});

let nextId = 0;
const pending = new Map();
socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  if (!message.id) return;
  const handler = pending.get(message.id);
  if (!handler) return;
  pending.delete(message.id);
  if (message.error) handler.reject(new Error(message.error.message));
  else handler.resolve(message.result);
});

function send(method, params = {}) {
  const id = ++nextId;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
  });
}

const result = await send("Runtime.evaluate", {
  expression: `(async () => {
    const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const setValue = (input, value) => {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      setter.call(input, value);
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    };
    const nameInput = document.querySelector("#repository-name-input");
    const descriptionInput = document.querySelector('input[name="Description"]');
    if (!nameInput || !descriptionInput) {
      return { started: false, reason: "repository form fields not found" };
    }
    setValue(nameInput, ${JSON.stringify(repoName)});
    setValue(descriptionInput, "卢朝鑫的个人作品小屋：暖色索引式作品集与可交互项目展示。");
    await wait(1000);
    const submit = [...document.querySelectorAll("button[type=submit]")]
      .find((button) => button.innerText.trim() === "Create repository");
    if (!submit || submit.disabled) {
      return {
        started: false,
        reason: submit ? "submit disabled" : "submit button not found",
        nameValidation: document.querySelector("#RepoNameInput-message")?.innerText || ""
      };
    }
    const form = submit.closest("form");
    if (form) form.requestSubmit(submit);
    else submit.click();
    return { started: true };
  })()`,
  awaitPromise: true,
  returnByValue: true
});
console.log(JSON.stringify(result.result.value, null, 2));
await new Promise((resolve) => setTimeout(resolve, 3500));
socket.close();
