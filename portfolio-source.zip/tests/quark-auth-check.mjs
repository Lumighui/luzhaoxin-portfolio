const port = Number(process.env.CDP_PORT || 9229);
const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
const target = targets.find((item) =>
  item.type === "page" && item.url.startsWith("https://github.com/")
);
if (!target) throw new Error("Authenticated GitHub page target not found");

const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});

let nextId = 0;
const pending = new Map();
socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  if (!message.id) return;
  const handler = pending.get(message.id);
  if (!handler) return;
  pending.delete(message.id);
  if (message.error) handler.reject(new Error(message.error.message));
  else handler.resolve(message.result);
});

function send(method, params = {}) {
  const id = ++nextId;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
  });
}

const response = await send("Runtime.evaluate", {
  expression: `(async () => {
    const result = await fetch("https://api.github.com/user", {
      credentials: "include",
      headers: { "Accept": "application/vnd.github+json" }
    });
    let body = null;
    try { body = await result.json(); } catch {}
    return {
      status: result.status,
      login: body?.login || null,
      id: body?.id || null,
      name: body?.name || null,
      publicRepos: body?.public_repos ?? null
    };
  })()`,
  awaitPromise: true,
  returnByValue: true
});
console.log(JSON.stringify({
  value: response.result?.value ?? null,
  description: response.result?.description ?? null,
  exceptionDetails: response.exceptionDetails ?? null
}, null, 2));
socket.close();
