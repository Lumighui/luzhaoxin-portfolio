import fs from "node:fs/promises";

const port = Number(process.env.CDP_PORT || 9229);
const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
const target = targets.find((item) =>
  item.type === "page" && item.url.includes("github.com/login")
);
if (!target) throw new Error("GitHub login target not found");

const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});

let nextId = 0;
const pending = new Map();
socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  if (!message.id) return;
  const handler = pending.get(message.id);
  if (!handler) return;
  pending.delete(message.id);
  if (message.error) handler.reject(new Error(message.error.message));
  else handler.resolve(message.result);
});

function send(method, params = {}) {
  const id = ++nextId;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
  });
}

await send("Page.enable");
const rectResult = await send("Runtime.evaluate", {
  expression: `(() => {
    const input = document.querySelector('input[name="login"]');
    if (!input) return null;
    input.scrollIntoView({ block: "center" });
    const rect = input.getBoundingClientRect();
    return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
  })()`,
  returnByValue: true
});
const point = rectResult.result.value;
if (point) {
  await send("Input.dispatchMouseEvent", {
    type: "mousePressed",
    x: point.x,
    y: point.y,
    button: "left",
    clickCount: 1
  });
  await send("Input.dispatchMouseEvent", {
    type: "mouseReleased",
    x: point.x,
    y: point.y,
    button: "left",
    clickCount: 1
  });
}
await new Promise((resolve) => setTimeout(resolve, 800));
const screenshot = await send("Page.captureScreenshot", {
  format: "png",
  fromSurface: true
});
await fs.writeFile(
  "output/playwright/quark-login-autofill-probe.png",
  Buffer.from(screenshot.data, "base64")
);
socket.close();
