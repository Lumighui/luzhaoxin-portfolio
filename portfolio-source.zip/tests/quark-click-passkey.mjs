const port = Number(process.env.CDP_PORT || 9229);
const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
const target = targets.find((item) =>
  item.type === "page" && item.url.includes("github.com/login")
);
if (!target) throw new Error("GitHub login target not found");

const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});

let nextId = 0;
const pending = new Map();
socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  if (!message.id) return;
  const handler = pending.get(message.id);
  if (!handler) return;
  pending.delete(message.id);
  if (message.error) handler.reject(new Error(message.error.message));
  else handler.resolve(message.result);
});

function send(method, params = {}) {
  const id = ++nextId;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
  });
}

const result = await send("Runtime.evaluate", {
  expression: `(() => {
    const button = [...document.querySelectorAll("button")]
      .find((item) => item.innerText.trim() === "Sign in with a passkey");
    if (!button) return { clicked: false, reason: "passkey button not found" };
    button.click();
    return { clicked: true };
  })()`,
  returnByValue: true
});
console.log(JSON.stringify(result.result.value, null, 2));
await new Promise((resolve) => setTimeout(resolve, 1500));
socket.close();
