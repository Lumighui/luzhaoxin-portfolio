import fs from "node:fs/promises";

const port = Number(process.env.CDP_PORT || 9229);
const targetUrlPart = process.env.TARGET_URL_PART || "github.com";
const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
const target = targets.find((item) =>
  item.type === "page" && item.url.includes(targetUrlPart)
);
if (!target) throw new Error(`Page target not found: ${targetUrlPart}`);

const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});

let nextId = 0;
const pending = new Map();
socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  if (!message.id) return;
  const handler = pending.get(message.id);
  if (!handler) return;
  pending.delete(message.id);
  if (message.error) handler.reject(new Error(message.error.message));
  else handler.resolve(message.result);
});

function send(method, params = {}) {
  const id = ++nextId;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
  });
}

await send("Page.enable");
const evaluation = await send("Runtime.evaluate", {
  expression: `({
    title: document.title,
    url: location.href,
    text: document.body.innerText.slice(0, 5000),
    actions: [...document.querySelectorAll("a, button")].map((element) => ({
      tag: element.tagName,
      text: element.innerText.trim(),
      href: element.href || "",
      type: element.type || ""
    })).filter((item) => item.text),
    inputs: [...document.querySelectorAll("input")].map((input) => ({
      name: input.name,
      type: input.type,
      placeholder: input.placeholder,
      autocomplete: input.autocomplete,
      id: input.id,
      ariaLabel: input.getAttribute("aria-label"),
      outerHTML: input.outerHTML.slice(0, 1200)
    })),
    githubCandidates: [...document.querySelectorAll("*")]
      .filter((element) => element.innerText?.trim() === "GitHub")
      .slice(0, 6)
      .map((element) => ({
        tag: element.tagName,
        className: element.className,
        outerHTML: element.outerHTML.slice(0, 2500),
        parentHTML: element.parentElement?.outerHTML.slice(0, 4000) || ""
      }))
  })`,
  returnByValue: true
});
console.log(JSON.stringify(evaluation.result.value, null, 2));

const screenshot = await send("Page.captureScreenshot", {
  format: "png",
  fromSurface: true
});
const outputName = targetUrlPart.includes("github") ? "quark-github-current.png" : "quark-scholar-current.png";
await fs.writeFile(`output/playwright/${outputName}`, Buffer.from(screenshot.data, "base64"));
socket.close();
