import fs from "node:fs/promises";
import path from "node:path";

const port = Number(process.env.CDP_PORT || 9229);
const keyPath = process.env.PUBLIC_KEY_PATH ||
  path.join(process.env.USERPROFILE, ".ssh", "id_ed25519_luzhaoxin_portfolio.pub");
const publicKey = (await fs.readFile(keyPath, "utf8")).trim();

const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
const target = targets.find((item) =>
  item.type === "page" && item.url.includes("github.com/settings/ssh/new")
);
if (!target) throw new Error("Add SSH key page target not found");

const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});

let nextId = 0;
const pending = new Map();
socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  if (!message.id) return;
  const handler = pending.get(message.id);
  if (!handler) return;
  pending.delete(message.id);
  if (message.error) handler.reject(new Error(message.error.message));
  else handler.resolve(message.result);
});

function send(method, params = {}) {
  const id = ++nextId;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
  });
}

const result = await send("Runtime.evaluate", {
  expression: `(async () => {
    const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const setValue = (element, value) => {
      const prototype = element instanceof HTMLTextAreaElement
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, "value").set;
      setter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
    };
    const title = document.querySelector("#ssh_key_title");
    const key = document.querySelector("#ssh_key_key") ||
      document.querySelector('textarea[name="ssh_key[key]"]');
    if (!title || !key) {
      return { started: false, reason: "SSH form fields not found" };
    }
    setValue(title, "Luzhaoxin Portfolio Deploy");
    setValue(key, ${JSON.stringify(publicKey)});
    await wait(200);
    const submit = [...document.querySelectorAll('button[type="submit"]')]
      .find((button) => button.innerText.trim() === "Add SSH key");
    if (!submit) return { started: false, reason: "submit not found" };
    const form = submit.closest("form");
    if (form) form.requestSubmit(submit);
    else submit.click();
    return { started: true };
  })()`,
  awaitPromise: true,
  returnByValue: true
});
console.log(JSON.stringify(result.result.value, null, 2));
await new Promise((resolve) => setTimeout(resolve, 3000));
socket.close();
