import fs from "node:fs/promises";
import path from "node:path";

const port = Number(process.env.CDP_PORT || 9333);
const pageUrl = process.env.PAGE_URL || "http://127.0.0.1:4173/";
const outputDir = path.resolve("output/playwright");

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function waitForTarget() {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/json/list`);
      if (response.ok) {
        const targets = await response.json();
        const target = targets.find((item) => item.type === "page" && item.url.startsWith(pageUrl));
        if (target) return target;
      }
    } catch {
      // Edge needs a moment to expose its DevTools endpoint.
    }
    await sleep(250);
  }
  throw new Error("Could not connect to the Edge DevTools endpoint");
}

const target = await waitForTarget();
const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});

let nextId = 0;
const pending = new Map();
const runtimeErrors = [];
const consoleErrors = [];
const networkFailures = [];
const badResponses = [];
const allowedOrigin = new URL(pageUrl).origin;

socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  if (message.method === "Runtime.exceptionThrown") {
    runtimeErrors.push(message.params.exceptionDetails.text);
  }
  if (message.method === "Runtime.consoleAPICalled" && message.params.type === "error") {
    consoleErrors.push(message.params.args.map((arg) => arg.value || arg.description).join(" "));
  }
  if (message.method === "Network.loadingFailed" && !message.params.canceled) {
    networkFailures.push({
      error: message.params.errorText,
      type: message.params.type
    });
  }
  if (message.method === "Network.responseReceived") {
    const response = message.params.response;
    if (response.url.startsWith(allowedOrigin) && response.status >= 400) {
      badResponses.push({ status: response.status, url: response.url });
    }
  }
  if (!message.id) return;
  const handler = pending.get(message.id);
  if (!handler) return;
  pending.delete(message.id);
  if (message.error) handler.reject(new Error(message.error.message));
  else handler.resolve(message.result);
});

function send(method, params = {}) {
  const id = ++nextId;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
  });
}

async function evaluate(expression) {
  const response = await send("Runtime.evaluate", {
    expression,
    returnByValue: true,
    awaitPromise: true
  });
  if (response.exceptionDetails) {
    throw new Error(response.exceptionDetails.exception?.description || response.exceptionDetails.text);
  }
  return response.result?.value;
}

async function setViewport(width, height, mobile = false) {
  await send("Emulation.setDeviceMetricsOverride", {
    width,
    height,
    deviceScaleFactor: 1,
    mobile
  });
}

async function screenshot(name, fullPage = true) {
  let clip;
  if (fullPage) {
    const metrics = await send("Page.getLayoutMetrics");
    const size = metrics.cssContentSize;
    clip = {
      x: 0,
      y: 0,
      width: Math.ceil(size.width),
      height: Math.ceil(size.height),
      scale: 1
    };
  }
  const result = await send("Page.captureScreenshot", {
    format: "png",
    fromSurface: true,
    captureBeyondViewport: fullPage,
    ...(clip ? { clip } : {})
  });
  await fs.writeFile(path.join(outputDir, name), Buffer.from(result.data, "base64"));
}

await fs.mkdir(outputDir, { recursive: true });
await send("Page.enable");
await send("Runtime.enable");
await send("Network.enable");
await setViewport(1440, 1100);
await send("Page.navigate", { url: pageUrl });
await sleep(1600);

const initial = await evaluate(String.raw`
(() => {
  const cards = [...document.querySelectorAll(".work-card")];
  const coverImage = document.querySelector(".work-card .work-cover img");
  return {
    title: document.title,
    cards: cards.length,
    modules: [...document.querySelectorAll(".module-section")].length,
    moduleNav: [...document.querySelectorAll("#moduleNav .module-nav-link")].map((item) => item.textContent.replace(/\s+/g, " ").trim()),
    search: Boolean(document.querySelector("#searchInput")),
    addButton: Boolean(document.querySelector("#addWorkButton")),
    layout: document.body.dataset.layout,
    theme: document.body.dataset.theme,
    siteName: document.querySelector("#sidebarSiteName")?.textContent,
    avatarLoaded: Boolean(document.querySelector("#profileAvatar")?.complete &&
      document.querySelector("#profileAvatar")?.naturalWidth > 0),
    coverLoaded: Boolean(coverImage?.complete && coverImage?.naturalWidth > 0),
    usesExternalSource: document.documentElement.innerHTML.includes("127.0.0.1:8765"),
    horizontalOverflow: document.documentElement.scrollWidth > document.documentElement.clientWidth + 1
  };
})()
`);

await screenshot("01-index-warm.png");

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  document.querySelector(".work-card .work-cover")?.click();
  await wait(120);
  return document.querySelector("#workDetailDialog").open;
})()
`);
await screenshot("00-work-detail.png", false);

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  document.querySelector(".detail-interactive-button")?.click();
  await wait(1100);
  return document.querySelector("#interactiveDialog").open;
})()
`);
await screenshot("00-interactive-view.png", false);

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  document.querySelector("#interactiveBackButton")?.click();
  await wait(150);
  document.querySelector("#closeDetailButton")?.click();
  await wait(80);
  return true;
})()
`);

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  document.querySelector('[data-work-id="work-mlp-neural-flight"] [data-action="open"]')?.click();
  await wait(120);
  return document.querySelector("#workDetailDialog").open;
})()
`);
await screenshot("00-mlp-detail.png", false);

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  document.querySelector(".detail-interactive-button")?.click();
  await wait(1200);
  return document.querySelector("#interactiveDialog").open;
})()
`);
await screenshot("00-mlp-interactive.png", false);

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  document.querySelector("#closeInteractiveButton")?.click();
  await wait(100);
  return true;
})()
`);

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const chooseLayout = async (layout) => {
    document.querySelector("#layoutButton").click();
    await wait(40);
    document.querySelector('[data-layout-choice="' + layout + '"]').click();
    document.querySelector("#layoutDoneButton").click();
    window.scrollTo(0, 0);
    await wait(180);
  };
  await chooseLayout("gallery");
  await chooseLayout("index");
  await chooseLayout("studio");
  return document.body.dataset.layout;
})()
`);

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  document.querySelector("#layoutButton").click();
  await wait(30);
  document.querySelector('[data-layout-choice="gallery"]').click();
  document.querySelector("#layoutDoneButton").click();
  window.scrollTo(0, 0);
  await wait(250);
  return true;
})()
`);
await screenshot("02-gallery-warm.png");

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  document.querySelector("#layoutButton").click();
  await wait(30);
  document.querySelector('[data-layout-choice="index"]').click();
  document.querySelector("#layoutDoneButton").click();
  window.scrollTo(0, 0);
  await wait(250);
  return true;
})()
`);
await screenshot("03-index-warm.png");

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  document.querySelector("#layoutButton").click();
  await wait(30);
  document.querySelector('[data-layout-choice="studio"]').click();
  document.querySelector("#layoutDoneButton").click();
  window.scrollTo(0, 0);
  if (document.body.dataset.theme === "light") document.querySelector("#themeButton").click();
  await wait(250);
  return document.body.dataset.theme;
})()
`);

const interactionChecks = await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const checks = {};
  const cardByTitle = (title) => [...document.querySelectorAll(".work-card")]
    .find((card) => card.querySelector(".work-title")?.textContent.trim() === title);

  const search = document.querySelector("#searchInput");
  search.value = "codex";
  search.dispatchEvent(new Event("input", { bubbles: true }));
  checks.searchFilters = document.querySelectorAll(".work-card").length === 1
    && document.querySelector(".work-title")?.textContent.includes("AI agent");
  document.querySelector("#clearSearchButton").click();
  checks.clearSearch = document.querySelectorAll(".work-card").length === 2;

  document.querySelector("#themeButton").click();
  checks.themeToggle = document.body.dataset.theme === "light";
  document.querySelector("#themeButton").click();
  checks.themeRestored = document.body.dataset.theme === "dark";

  document.querySelector("#addWorkButton").click();
  checks.editorOpens = document.querySelector("#workEditorDialog").open;
  document.querySelector("#fieldModuleTitle").value = "测试板块";
  document.querySelector("#fieldWorkTitle").value = "自动化测试作品";
  document.querySelector("#fieldSummary").value = "用于验证新增、图片、编辑、持久化和删除的测试作品。";
  document.querySelector("#fieldBody").value = "第一段测试正文。\n\n第二段测试正文。";
  document.querySelector("#fieldLinks").value = "测试链接 | https://example.com/test";
  document.querySelector("#fieldTags").value = "测试, 自动化";
  document.querySelector("#fieldWorkDate").value = "2026-11-18";
  document.querySelector("#fieldWorkStatus").value = "published";

  const canvas = document.createElement("canvas");
  canvas.width = 640;
  canvas.height = 420;
  const context = canvas.getContext("2d");
  const gradient = context.createLinearGradient(0, 0, 640, 420);
  gradient.addColorStop(0, "#17211d");
  gradient.addColorStop(1, "#a8c4a1");
  context.fillStyle = gradient;
  context.fillRect(0, 0, 640, 420);
  context.strokeStyle = "rgba(255,255,255,.5)";
  context.lineWidth = 2;
  context.strokeRect(60, 60, 520, 300);
  const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
  const transfer = new DataTransfer();
  transfer.items.add(new File([blob], "test-cover.png", { type: "image/png" }));
  const imageInput = document.querySelector("#fieldImages");
  imageInput.files = transfer.files;
  imageInput.dispatchEvent(new Event("change", { bubbles: true }));
  await wait(900);
  checks.imageUpload = document.querySelectorAll(".editor-image").length === 1;

  document.querySelector("#workForm").requestSubmit();
  await wait(900);
  checks.addWork = Boolean(cardByTitle("自动化测试作品"));
  checks.autoCreateModule = [...document.querySelectorAll(".module-title")]
    .some((heading) => heading.textContent.trim() === "测试板块");
  checks.coverSaved = Boolean(cardByTitle("自动化测试作品")?.querySelector(".work-cover img"));

  cardByTitle("自动化测试作品")?.querySelector('[data-action="open"]')?.click();
  await wait(80);
  checks.detailOpens = document.querySelector("#workDetailDialog").open
    && document.querySelector("#detailTitle")?.textContent === "自动化测试作品";
  checks.detailImage = Boolean(document.querySelector(".detail-hero-image"));
  document.querySelector("#closeDetailButton").click();

  cardByTitle("我和我的AI——AI agent使用情况")?.querySelector('[data-action="open"]')?.click();
  await wait(80);
  checks.realWorkDetail = document.querySelector("#workDetailDialog").open
    && document.querySelector("#detailTitle")?.textContent === "我和我的AI——AI agent使用情况"
    && Boolean(document.querySelector(".detail-interactive-button"));
  document.querySelector(".detail-interactive-button")?.click();
  await wait(900);
  checks.interactiveViewer = document.querySelector("#interactiveDialog").open;
  const embeddedDocument = document.querySelector("#interactiveFrame")?.contentDocument;
  checks.embeddedProject = embeddedDocument?.title === "我和我的AI——AI agent使用情况"
    && embeddedDocument?.querySelectorAll(".tool-card").length === 3;
  checks.embeddedManagementHidden = embeddedDocument?.body.classList.contains("is-embedded")
    && getComputedStyle(embeddedDocument.querySelector("#manageButton")).display === "none";
  document.querySelector("#interactiveBackButton").click();
  await wait(120);
  checks.returnToDetail = document.querySelector("#workDetailDialog").open
    && document.querySelector("#detailTitle")?.textContent === "我和我的AI——AI agent使用情况";
  document.querySelector("#closeDetailButton").click();

  cardByTitle("MLP学习参数的实现和可视化")?.querySelector('[data-action="open"]')?.click();
  await wait(80);
  checks.mlpDetail = document.querySelector("#workDetailDialog").open
    && document.querySelector("#detailTitle")?.textContent === "MLP学习参数的实现和可视化"
    && Boolean(document.querySelector(".detail-interactive-button"));
  document.querySelector(".detail-interactive-button")?.click();
  await wait(1200);
  checks.mlpViewer = document.querySelector("#interactiveDialog").open;
  const mlpDocument = document.querySelector("#interactiveFrame")?.contentDocument;
  checks.mlpEmbeddedProject = mlpDocument?.title.startsWith("MLP学习参数的实现和可视化")
    && mlpDocument?.querySelectorAll(".flow-card").length === 7
    && Boolean(mlpDocument?.querySelector("#networkCanvas"))
    && getComputedStyle(mlpDocument.querySelector(".site-header")).display === "none";
  mlpDocument?.querySelector("#nextBtn")?.click();
  await wait(100);
  checks.mlpInteraction = mlpDocument?.querySelector("#sceneStep")?.textContent.trim() === "01 / 07";
  document.querySelector("#closeInteractiveButton").click();
  await wait(80);

  return checks;
})()
`);

await send("Page.reload", { ignoreCache: true });
await sleep(1500);

const persistenceAndEditing = await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const checks = {};
  const cardByTitle = (title) => [...document.querySelectorAll(".work-card")]
    .find((card) => card.querySelector(".work-title")?.textContent.trim() === title);

  checks.persistedAfterReload = Boolean(cardByTitle("自动化测试作品"));
  cardByTitle("自动化测试作品")?.querySelector('[data-action="edit"]')?.click();
  await wait(50);
  document.querySelector("#fieldWorkTitle").value = "自动化测试作品（已编辑）";
  document.querySelector("#fieldSummary").value = "编辑后的摘要。";
  document.querySelector("#workForm").requestSubmit();
  await wait(700);
  checks.editWork = Boolean(cardByTitle("自动化测试作品（已编辑）"))
    && !cardByTitle("自动化测试作品");

  let exportedText = "";
  const originalCreateObjectUrl = URL.createObjectURL;
  const originalAnchorClick = HTMLAnchorElement.prototype.click;
  URL.createObjectURL = (blob) => {
    blob.text().then((text) => { exportedText = text; });
    return "blob:test";
  };
  HTMLAnchorElement.prototype.click = () => {};
  document.querySelector("#settingsButton").click();
  await wait(50);
  document.querySelector('[data-settings-tab="backup"]').click();
  document.querySelector("#exportBackupButton").click();
  await wait(50);
  URL.createObjectURL = originalCreateObjectUrl;
  HTMLAnchorElement.prototype.click = originalAnchorClick;
  try {
    const parsed = JSON.parse(exportedText);
    checks.exportBackup = Array.isArray(parsed.works) && parsed.works.length === 3;
  } catch {
    checks.exportBackup = false;
  }

  document.querySelector('[data-settings-tab="profile"]').click();
  document.querySelector("#fieldSiteName").value = "测试小站";
  document.querySelector("#settingsForm").requestSubmit();
  await wait(400);
  checks.settingsSaved = document.querySelector("#sidebarSiteName").textContent === "测试小站";

  window.confirm = () => true;
  cardByTitle("自动化测试作品（已编辑）")?.querySelector('[data-action="delete"]')?.click();
  await wait(600);
  checks.deleteWork = !cardByTitle("自动化测试作品（已编辑）");

  document.querySelector("#settingsButton").click();
  await wait(50);
  document.querySelector('[data-settings-tab="backup"]').click();
  document.querySelector("#resetDemoButton").click();
  await wait(800);
  checks.resetDemo = document.querySelectorAll(".work-card").length === 2
    && document.querySelector("#sidebarSiteName").textContent === "卢朝鑫的作品小屋";
  return checks;
})()
`);

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  document.querySelector("#layoutButton").click();
  await wait(30);
  document.querySelector('[data-layout-choice="index"]').click();
  document.querySelector("#layoutDoneButton").click();
  window.scrollTo(0, 0);
  await wait(100);
  return true;
})()
`);
await screenshot("04-index-final.png");

await evaluate(String.raw`
(async () => {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  if (document.body.dataset.theme === "dark") document.querySelector("#themeButton").click();
  window.scrollTo(0, 0);
  await wait(180);
  return document.body.dataset.theme;
})()
`);
await screenshot("05-index-light.png");
await evaluate(`document.querySelector("#themeButton").click()`);

await setViewport(390, 844, true);
await send("Page.reload", { ignoreCache: true });
await sleep(1200);
const mobile = await evaluate(String.raw`
(() => {
  const sidebarOpenBefore = document.querySelector("#sidebar").classList.contains("is-open");
  document.querySelector("#openSidebarButton").click();
  const sidebarOpenAfter = document.querySelector("#sidebar").classList.contains("is-open");
  document.querySelector("#closeSidebarButton").click();
  return {
    width: window.innerWidth,
    cards: document.querySelectorAll(".work-card").length,
    horizontalOverflow: document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
    sidebarOpenBefore,
    sidebarOpenAfter,
    sidebarClosed: !document.querySelector("#sidebar").classList.contains("is-open")
  };
})()
`);
await screenshot("06-mobile.png");

const checks = {
  ...interactionChecks,
  ...persistenceAndEditing,
  initialCards: initial.cards === 2,
  initialModules: initial.modules === 1,
  initialTitle: initial.title === "卢朝鑫的作品小屋",
  initialSiteName: initial.siteName === "卢朝鑫的作品小屋",
  initialLayout: initial.layout === "index",
  initialAvatar: initial.avatarLoaded,
  warmCover: initial.coverLoaded,
  noExternalSource: !initial.usesExternalSource,
  initialNavigation: initial.moduleNav.length === 1
    && initial.moduleNav[0].includes("AI 实验")
    && initial.moduleNav[0].includes("02"),
  initialNoOverflow: !initial.horizontalOverflow,
  mobileCards: mobile.cards === 2,
  mobileNoOverflow: !mobile.horizontalOverflow,
  mobileSidebar: !mobile.sidebarOpenBefore && mobile.sidebarOpenAfter && mobile.sidebarClosed,
  noRuntimeErrors: runtimeErrors.length === 0,
  noConsoleErrors: consoleErrors.length === 0,
  noNetworkFailures: networkFailures.length === 0,
  noBadResponses: badResponses.length === 0
};

console.log(JSON.stringify({
  all: Object.values(checks).every(Boolean),
  checks,
  initial,
  mobile,
  runtimeErrors,
  consoleErrors,
  networkFailures,
  badResponses
}, null, 2));

socket.close();

if (!Object.values(checks).every(Boolean)) {
  process.exitCode = 1;
}
